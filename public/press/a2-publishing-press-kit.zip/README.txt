A² Publishing, Double the Adventure press kit.

Images are free to use with the credit "© A² Publishing".
Covers are web size (900 px wide). 300 dpi files, sample spreads and character art: ask ceo@doubleadventure.ca.
https://doubleadventure.ca/partners/press
